# Assignment 6: Graph-based Sentiment Analysis with RNN
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import random
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.preprocessing.sequence import pad_sequences

n_nodes = 20
G = nx.gnm_random_graph(n_nodes, 30, seed=42)

for u, v in G.edges():
    G[u][v]['sentiment'] = np.random.choice([0, 1])

plt.figure(figsize=(8, 6))
pos = nx.spring_layout(G, seed=42)
edge_colours = ['red' if G[u][v]['sentiment'] == 0 else 'green' for u, v in G.edges()]
nx.draw(G, pos, with_labels=True, node_color='lightblue', edge_color=edge_colours, width=2, font_weight='bold', node_size=500)
plt.title("Original Network Graph (Red=Neg, Green=Pos)")
plt.show()

max_walk_len = 4
walks = []
labels = []

for start_node in G.nodes():
    walk = [start_node]
    current = start_node
    for _ in range(max_walk_len - 1):
        neighbors = list(G.neighbors(current))
        if not neighbors:
            break
        next_node = random.choice(neighbors)
        walk.append(next_node)
        current = next_node
    if len(walk) >= 2:
        walks.append(walk)
        u, v = walk[-2], walk[-1]
        labels.append(G[u][v]['sentiment'])

walks_padded = pad_sequences(walks, maxlen=max_walk_len, value=n_nodes)
labels = np.array(labels)

X_train, X_test, y_train, y_test = train_test_split(walks_padded, labels, test_size=0.2, random_state=42)

vocab_size = n_nodes + 1
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=8, input_length=max_walk_len),
    LSTM(32),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
history = model.fit(X_train, y_train, epochs=30, batch_size=8, validation_data=(X_test, y_test), verbose=0)

train_loss, train_acc = model.evaluate(X_train, y_train, verbose=0)
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Training Accuracy: {train_acc:.4f}")
print(f"Test Accuracy: {test_acc:.4f}")

y_pred_prob = model.predict(X_test, verbose=0)
y_pred = (y_pred_prob > 0.5).astype(int).flatten()

comparison = pd.DataFrame({
    'Sequence': [str(seq[:seq.tolist().index(n_nodes)] if n_nodes in seq else seq) for seq in X_test],
    'True Sentiment': y_test,
    'Predicted Sentiment': y_pred,
    'Probability': y_pred_prob.flatten()
})
print("\nSample Test Predictions:")
print(comparison.head(10).to_string(index=False))

edge_pred = {}
for walk in walks_padded:
    u, v = walk[-2], walk[-1]
    if u != n_nodes and v != n_nodes:
        prob = model.predict(np.array([walk]), verbose=0)[0][0]
        edge_pred[(u, v)] = int(prob > 0.5)

plt.figure(figsize=(8, 6))
nx.draw_networkx_edges(G, pos, edgelist=G.edges(), edge_color='gray', width=1, alpha=0.3)
pred_edge_list = list(edge_pred.keys())
pred_edge_colours = ['red' if pred == 0 else 'green' for pred in edge_pred.values()]
nx.draw_networkx_edges(G, pos, edgelist=pred_edge_list, edge_color=pred_edge_colours, width=2)
nx.draw_networkx_nodes(G, pos, node_color='lightblue', node_size=500)
nx.draw_networkx_labels(G, pos, font_weight='bold')
plt.title("Network Graph - Predicted Sentiments (Red=Neg, Green=Pos)")
plt.show()

plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.plot(history.history['accuracy'], label='Train Acc')
plt.plot(history.history['val_accuracy'], label='Val Acc')
plt.title('Accuracy over Epochs')
plt.legend()
plt.grid(True)

plt.subplot(1,2,2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Loss over Epochs')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()