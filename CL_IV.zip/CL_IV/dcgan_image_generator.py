# Assignment 5: DCGAN to Generate MNIST Digits (Optimized for Speed)
import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
import matplotlib.pyplot as plt
import time # Added to track epoch speed

# 1. Load and Preprocess Data
(x_train, _), (_, _) = tf.keras.datasets.mnist.load_data()
x_train = (x_train.astype('float32') - 127.5) / 127.5
x_train = np.expand_dims(x_train, axis=-1)

BUFFER_SIZE = 60000
BATCH_SIZE = 256 # Increased to 256 to process more images simultaneously on the GPU
EPOCHS = 30
NOISE_DIM = 100

# 2. Optimized Data Pipeline (The Fix for Data Starvation)
AUTOTUNE = tf.data.AUTOTUNE
dataset = tf.data.Dataset.from_tensor_slices(x_train)\
    .shuffle(BUFFER_SIZE)\
    .batch(BATCH_SIZE)\
    .cache()\
    .prefetch(AUTOTUNE) # This tells the CPU to prepare the next batch while the GPU is working

# 3. DCGAN Architecture (Strictly per theory)
def make_generator():
    model = models.Sequential([
        layers.Dense(7*7*256, use_bias=False, input_shape=(NOISE_DIM,)),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.Reshape((7, 7, 256)),
        layers.Conv2DTranspose(128, (4,4), strides=(2,2), padding='same', use_bias=False),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.Conv2DTranspose(64, (4,4), strides=(2,2), padding='same', use_bias=False),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.Conv2DTranspose(1, (4,4), strides=(1,1), padding='same', activation='tanh')
    ])
    return model

def make_discriminator():
    model = models.Sequential([
        layers.Conv2D(64, (4,4), strides=(2,2), padding='same', input_shape=(28,28,1)),
        layers.LeakyReLU(alpha=0.2),
        layers.Dropout(0.3),
        layers.Conv2D(128, (4,4), strides=(2,2), padding='same'),
        layers.LeakyReLU(alpha=0.2),
        layers.Dropout(0.3),
        layers.Flatten(),
        layers.Dense(1, activation='sigmoid')
    ])
    return model

generator = make_generator()
discriminator = make_discriminator()

cross_entropy = tf.keras.losses.BinaryCrossentropy(from_logits=False)

def generator_loss(fake_output):
    return cross_entropy(tf.ones_like(fake_output), fake_output)

def discriminator_loss(real_output, fake_output):
    real_loss = cross_entropy(tf.ones_like(real_output), real_output)
    fake_loss = cross_entropy(tf.zeros_like(fake_output), fake_output)
    return real_loss + fake_loss

generator_optimizer = tf.keras.optimizers.Adam(learning_rate=0.0002, beta_1=0.5)
discriminator_optimizer = tf.keras.optimizers.Adam(learning_rate=0.0002, beta_1=0.5)

@tf.function
def train_step(images):
    noise = tf.random.normal([BATCH_SIZE, NOISE_DIM])
    with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
        generated_images = generator(noise, training=True)
        real_output = discriminator(images, training=True)
        fake_output = discriminator(generated_images, training=True)
        gen_loss = generator_loss(fake_output)
        disc_loss = discriminator_loss(real_output, fake_output)
    
    gradients_of_generator = gen_tape.gradient(gen_loss, generator.trainable_variables)
    gradients_of_discriminator = disc_tape.gradient(disc_loss, discriminator.trainable_variables)
    
    generator_optimizer.apply_gradients(zip(gradients_of_generator, generator.trainable_variables))
    discriminator_optimizer.apply_gradients(zip(gradients_of_discriminator, discriminator.trainable_variables))
    
    return gen_loss, disc_loss

# 4. Training Loop
seed = tf.random.normal([16, NOISE_DIM])

print("Starting Training...")
for epoch in range(EPOCHS):
    start_time = time.time() # Start timer
    
    for image_batch in dataset:
        # Handle the last batch if it's smaller than BATCH_SIZE to avoid graph errors
        if image_batch.shape[0] == BATCH_SIZE: 
            g_loss, d_loss = train_step(image_batch)
            
    epoch_time = time.time() - start_time
    print(f"Epoch {epoch+1}/{EPOCHS} completed in {epoch_time:.1f} sec | Gen Loss: {g_loss:.4f} | Disc Loss: {d_loss:.4f}")
    
    if (epoch + 1) % 10 == 0 or epoch == 0:
        generated = (generator(seed, training=False) + 1) / 2.0
        fig, axes = plt.subplots(4, 4, figsize=(4,4))
        for i, ax in enumerate(axes.flatten()):
            ax.imshow(generated[i, :, :, 0], cmap='gray')
            ax.axis('off')
        plt.suptitle(f"Epoch {epoch+1}")
        plt.tight_layout()
        plt.show()

# Final generation
test_noise = tf.random.normal([25, NOISE_DIM])
generated = (generator(test_noise, training=False) + 1) / 2.0
fig, axes = plt.subplots(5, 5, figsize=(6,6))
for i in range(5):
    for j in range(5):
        axes[i, j].imshow(generated[i*5+j, :, :, 0], cmap='gray')
        axes[i, j].axis('off')
plt.suptitle("DCGAN Generated MNIST Digits")
plt.tight_layout()
plt.show()