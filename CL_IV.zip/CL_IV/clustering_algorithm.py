# Assignment 12: Data Clustering using K-Means
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans

# Generate synthetic dataset
X, _ = make_blobs(n_samples=300, centers=3, cluster_std=0.8, random_state=42)
df = pd.DataFrame(X, columns=['Feature 1', 'Feature 2'])

# Apply K-Means clustering
kmeans = KMeans(n_clusters=3, random_state=42)
df['Cluster'] = kmeans.fit_predict(X)

# Print results
print("Dataset with Cluster Labels (first 5 rows):")
print(df.head())

print("\nCluster Centers:")
centers_df = pd.DataFrame(kmeans.cluster_centers_, columns=['Feature 1', 'Feature 2'])
centers_df.index.name = 'Cluster'
print(centers_df)

# Visual output
plt.figure(figsize=(7,5))
colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
for i in range(3):
    cluster_points = df[df['Cluster'] == i]
    plt.scatter(cluster_points['Feature 1'], cluster_points['Feature 2'], c=colors[i], label=f'Cluster {i}', edgecolor='k', s=50)

plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], c='red', marker='X', s=200, label='Centroids')
plt.title('K-Means Clustering (k=3)')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()