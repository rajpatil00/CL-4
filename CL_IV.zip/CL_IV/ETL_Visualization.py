#Assignment 8: ETL and Visualization
import pandas as pd
import sqlite3
import matplotlib.pyplot as plt

# 1. Extraction: Load data from source
url = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df_extracted = pd.read_csv(url)
print("Extracted Data:")
print(df_extracted.head(), "\n")

# 2. Transformation: Clean and aggregate data
df_transformed = df_extracted[['Pclass', 'Sex', 'Age', 'Fare']].dropna()
df_transformed['Age_Group'] = pd.cut(df_transformed['Age'], bins=[0, 18, 40, 80], labels=['Child', 'Adult', 'Senior'])
df_agg = df_transformed.groupby(['Pclass', 'Sex'])['Fare'].mean().reset_index()
print("Transformed Data:")
print(df_agg, "\n")

# 3. Loading: Store transformed data into a database
conn = sqlite3.connect(':memory:')
df_agg.to_sql('Fare_Analysis', conn, index=False, if_exists='replace')

# 4. Visualization: Read from loaded database and plot
df_loaded = pd.read_sql("SELECT * FROM Fare_Analysis", conn)

plt.figure(figsize=(8, 5))
for sex in df_loaded['Sex'].unique():
    subset = df_loaded[df_loaded['Sex'] == sex]
    plt.bar(subset['Pclass'].astype(str) + " (" + sex + ")", subset['Fare'], label=sex)

plt.xlabel("Passenger Class & Sex")
plt.ylabel("Average Fare")
plt.title("Data Visualization from ETL Process")
plt.legend()
plt.tight_layout()
plt.show()

conn.close()