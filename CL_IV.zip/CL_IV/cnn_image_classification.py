# Assignment 4: CNN for Image Classification with Hyperparameter Tuning
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from tensorflow.keras import datasets, layers, models, Input
from tensorflow.keras.optimizers import Adam, SGD, RMSprop

# a) Select a suitable image classification dataset
(x_train, y_train), (x_test, y_test) = datasets.mnist.load_data()

# Cast to float32 (runs much faster on GPUs) and normalize
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)

x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.1, random_state=42)

def build_cnn(input_shape=(28,28,1), num_classes=10, filters=[32, 64, 128],
              kernel_size=(3,3), dropout_rate=0.5, dense_units=128,
              optimizer='adam', learning_rate=0.001):

    model = models.Sequential()
    model.add(Input(shape=input_shape))
    
    # Use padding='same' to prevent spatial dimensions from shrinking too fast
    model.add(layers.Conv2D(filters[0], kernel_size, activation='relu', padding='same'))
    model.add(layers.MaxPooling2D((2,2)))

    for f in filters[1:]:
        model.add(layers.Conv2D(f, kernel_size, activation='relu', padding='same'))
        model.add(layers.MaxPooling2D((2,2)))

    model.add(layers.Flatten())
    model.add(layers.Dropout(dropout_rate))
    model.add(layers.Dense(dense_units, activation='relu'))
    model.add(layers.Dense(num_classes, activation='softmax'))

    # b) Optimized with different hyperparameters
    if optimizer == 'adam':
        opt = Adam(learning_rate=learning_rate)
    elif optimizer == 'sgd':
        opt = SGD(learning_rate=learning_rate)
    elif optimizer == 'rmsprop':
        opt = RMSprop(learning_rate=learning_rate)
    else:
        opt = Adam(learning_rate=learning_rate)

    model.compile(optimizer=opt, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

# Increased batch_size to 256 for massive GPU speedup
configs = [
    {'name': 'Baseline', 'filters': [32, 64, 128], 'dropout_rate': 0.5, 'dense_units': 128, 'optimizer': 'adam', 'learning_rate': 0.001, 'epochs': 5, 'batch_size': 256},
    {'name': 'Increased Filters', 'filters': [64, 128, 256], 'dropout_rate': 0.5, 'dense_units': 128, 'optimizer': 'adam', 'learning_rate': 0.001, 'epochs': 5, 'batch_size': 256},
    {'name': 'More Layers', 'filters': [32, 64, 128, 128], 'dropout_rate': 0.5, 'dense_units': 128, 'optimizer': 'adam', 'learning_rate': 0.001, 'epochs': 5, 'batch_size': 256},
    {'name': 'Higher Dropout', 'filters': [32, 64, 128], 'dropout_rate': 0.7, 'dense_units': 128, 'optimizer': 'adam', 'learning_rate': 0.001, 'epochs': 5, 'batch_size': 256},
    {'name': 'SGD Optimizer', 'filters': [32, 64, 128], 'dropout_rate': 0.5, 'dense_units': 128, 'optimizer': 'sgd', 'learning_rate': 0.01, 'epochs': 5, 'batch_size': 256},
    {'name': 'Lower LR (Adam)', 'filters': [32, 64, 128], 'dropout_rate': 0.5, 'dense_units': 128, 'optimizer': 'adam', 'learning_rate': 0.0001, 'epochs': 5, 'batch_size': 256}
]

results = []
histories = {}

for i, cfg in enumerate(configs):
    print(f"\n--- Training Configuration {i+1}/{len(configs)}: {cfg['name']} ---")
    
    model = build_cnn(filters=cfg['filters'], dropout_rate=cfg['dropout_rate'],
                      dense_units=cfg['dense_units'], optimizer=cfg['optimizer'],
                      learning_rate=cfg['learning_rate'])

    # Changed verbose=0 to verbose=2. This prints one clean line per epoch so you can see progress.
    history = model.fit(x_train, y_train, validation_data=(x_val, y_val),
                        epochs=cfg['epochs'], batch_size=cfg['batch_size'], verbose=2)

    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)

    results.append({
        'Configuration': cfg['name'], 'Layers': len(cfg['filters']),
        'Filter Sizes': str(cfg['filters']), 'Dropout': cfg['dropout_rate'],
        'Optimizer': cfg['optimizer'].upper(), 'Learning Rate': cfg['learning_rate'],
        'Val Accuracy': history.history['val_accuracy'][-1], 'Test Accuracy': test_acc
    })
    histories[cfg['name']] = history.history

results_df = pd.DataFrame(results).sort_values('Test Accuracy', ascending=False)
print("\n=== Comparison of Hyperparameter Configurations ===")
print(results_df.to_string(index=False))

# Visualizations
plt.figure(figsize=(10,5))
for cfg in configs:
    validation_acc = histories[cfg['name']]['val_accuracy']
    plt.plot(range(1, len(validation_acc)+1), validation_acc, marker='o', label=cfg['name'])
plt.title('Validation Accuracy Across Configurations')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

plt.figure(figsize=(8,4))
names = [r['Configuration'] for r in results]
test_accs = [r['Test Accuracy'] for r in results]
colors = plt.cm.viridis(np.linspace(0.2, 0.8, len(names)))
plt.bar(names, test_accs, color=colors)
plt.title('Test Accuracy of Each Configuration')
plt.ylabel('Accuracy')
plt.xticks(rotation=45, ha='right')
# Adjusted y-limit to better show differences
plt.ylim(0.85, 1.0) 
plt.tight_layout()
plt.show()