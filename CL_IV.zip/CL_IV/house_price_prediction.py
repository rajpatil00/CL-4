# Assignment 1: Linear Regression for House Price Prediction
# Dataset: USA_Housing.csv

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load dataset
url = "https://raw.githubusercontent.com/ageron/handson-ml/master/datasets/housing/housing.csv"
df = pd.read_csv(url)

# Handle missing values (impute with median)
df['total_bedrooms'].fillna(df['total_bedrooms'].median(), inplace=True)

# Display first 5 rows
print("First 5 rows of the dataset:")
print(df.head())

# Select features and target
features = ['longitude', 'latitude', 'housing_median_age', 'total_rooms',
            'total_bedrooms', 'population', 'households', 'median_income']
target = 'median_house_value'
X = df[features]
y = df[target]

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluate model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print("\nModel Evaluation Metrics")
print(f"Mean Squared Error (MSE): {mse:,.2f}")
print(f"R-squared (R²): {r2:.4f}")

# Visual output: Actual vs. Predicted Prices
plt.figure(figsize=(7,5))
plt.scatter(y_test, y_pred, alpha=0.5, edgecolors='k')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Linear Regression: Actual vs. Predicted House Prices")
plt.grid(True)
plt.show()

# Sample predictions vs actuals
comparison = pd.DataFrame({
    'Actual Price': y_test.head(10).values,
    'Predicted Price': y_pred[:10].round(2)
})
print("\nSample of Test Set Predictions (first 10 rows)")
print(comparison)
